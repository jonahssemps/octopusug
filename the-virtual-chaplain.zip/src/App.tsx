/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import Home from './components/Home';
import Reader from './components/Reader';
import Chaplain from './components/Chaplain';
import Plans from './components/Plans';
import Search from './components/Search';
import Settings from './components/Settings';
import Navbar from './components/layout/Navbar';
import { AnimatePresence, motion } from 'motion/react';
import { LanguageProvider } from './context/LanguageContext';

export default function App() {
  const [activeTab, setActiveTab] = useState('home');

  const renderContent = () => {
    switch (activeTab) {
      case 'home': return <Home />;
      case 'bible': return <Reader />;
      case 'plans': return <Plans setActiveTab={setActiveTab} />;
      case 'search': return <Search />;
      case 'chaplain': return <Chaplain />;
      case 'settings': return <Settings />;
      default: return <Home />;
    }
  };

  return (
    <LanguageProvider>
      <div className="min-h-screen pb-20">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, scale: 0.99 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.01 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
            className="max-w-4xl mx-auto"
          >
            {renderContent()}
          </motion.div>
        </AnimatePresence>

        <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />
      </div>
    </LanguageProvider>
  );
}
