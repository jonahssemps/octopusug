
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export const getChaplainResponse = async (history: { role: 'user' | 'model', parts: { text: string }[]}[], prompt: string) => {
  const model = "gemini-3-flash-preview";
  
  const chat = ai.chats.create({
    model,
    config: {
      systemInstruction: "You are 'The Chaplain', a compassionate, wise, and encouraging spiritual guide. Your goal is to help users understand the Bible (Good News translation) and find peace in their daily lives. Use scripture to provide context, explain complex verses in simple terms, and offer prayers or meditations when appropriate. Keep your tone gentle and accessible for all ages.",
    },
    history,
  });

  const result = await chat.sendMessage({
    message: prompt,
  });

  return result.text;
};

export const generateDailyVerse = async () => {
    const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: "Pick a powerful and encouraging verse from the Good News Bible for today. Return it in JSON format with fields: reference, text, and a short reflection.",
        config: {
            responseMimeType: "application/json",
        }
    });
    return JSON.parse(response.text || '{}');
}
