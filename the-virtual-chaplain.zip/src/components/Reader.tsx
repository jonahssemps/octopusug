
import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown, Play, Pause, Bookmark, Share2, Volume2, Search, Download } from 'lucide-react';
import { BIBLE_BOOKS, getChapter, getVerseAudio } from '../services/bibleService';
import { Verse } from '../types';

export default function Reader() {
  const [selectedBook, setSelectedBook] = useState(BIBLE_BOOKS[0]);
  const [selectedChapter, setSelectedChapter] = useState(1);
  const [verses, setVerses] = useState<Verse[]>([]);
  const [loading, setLoading] = useState(true);
  const [showBookSelector, setShowBookSelector] = useState(false);
  const [playingVerseId, setPlayingVerseId] = useState<string | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);

  const [isPlayingChapter, setIsPlayingChapter] = useState(false);

  const audioRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    async function loadChapter() {
      setLoading(true);
      const data = await getChapter(selectedBook.name, selectedChapter);
      setVerses(data);
      setLoading(false);
      setAudioUrl(null);
      setPlayingVerseId(null);
      setIsPlayingChapter(false);
    }
    loadChapter();
  }, [selectedBook, selectedChapter]);

  const handlePlayVerse = async (verse: Verse) => {
    if (playingVerseId === verse.id) {
      setPlayingVerseId(null);
      setAudioUrl(null);
      return;
    }

    setIsPlayingChapter(false);
    setPlayingVerseId(verse.id);
    const url = await getVerseAudio(verse.text);
    setAudioUrl(url);
  };

  const handlePlayChapter = async () => {
    if (isPlayingChapter) {
      setIsPlayingChapter(false);
      setAudioUrl(null);
      setPlayingVerseId(null);
      return;
    }

    setPlayingVerseId(null);
    setIsPlayingChapter(true);
    const fullText = verses.map(v => v.text).join(' ');
    const url = await getVerseAudio(fullText);
    setAudioUrl(url);
  };

  const handleShare = (verse: Verse) => {
     const text = `"${verse.text}" - ${selectedBook.name} ${selectedChapter}:${verse.verse} (GNT)`;
     if (navigator.share) {
       navigator.share({ title: 'Bible Verse', text })
         .catch(err => {
           console.error('Error sharing:', err);
           copyToClipboard(text);
         });
     } else {
       copyToClipboard(text);
     }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      alert('Verse copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy:', err);
    });
  };

  return (
    <div className="min-h-screen flex flex-col bg-brand-blue-bg">
      {/* Reader Header / Navigation */}
      <header className="sticky top-0 bg-white/80 backdrop-blur-md border-b border-brand-blue-main/5 p-4 z-40 flex items-center justify-between shadow-sm">
        <div 
          className="flex items-center gap-3 cursor-pointer group bg-brand-blue-main/5 px-4 py-2 rounded-2xl border border-brand-blue-main/5 hover:bg-brand-blue-main/10 transition-all"
          onClick={() => setShowBookSelector(!showBookSelector)}
        >
          <div className="flex flex-col">
            <span className="text-[10px] text-brand-blue-main font-black uppercase tracking-widest">Scripture</span>
            <h2 className="text-sm font-serif font-bold text-brand-ink">{selectedBook.name} {selectedChapter}</h2>
          </div>
          <ChevronDown size={16} className={`text-brand-blue-main transition-transform duration-300 ${showBookSelector ? 'rotate-180' : ''}`} />
        </div>

        <div className="flex items-center gap-2">
           <button 
             onClick={handlePlayChapter}
             className={`p-2.5 rounded-xl transition-all ${isPlayingChapter ? 'bg-brand-blue-main text-white shadow-lg' : 'text-gray-400 hover:text-brand-blue-main hover:bg-white'}`}
           >
              {isPlayingChapter ? <Pause size={20} /> : <Volume2 size={20} />}
           </button>
           <button className="p-2.5 text-gray-400 hover:text-brand-blue-main hover:bg-white rounded-xl transition-all">
              <Download size={20} />
           </button>
        </div>
      </header>

      {/* Book & Chapter Selector */}
      <AnimatePresence>
        {showBookSelector && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="fixed inset-x-4 top-[80px] bottom-32 bg-white rounded-[40px] z-50 p-8 shadow-2xl border border-brand-blue-main/5 overflow-hidden flex flex-col"
          >
            <div className="flex justify-between items-center mb-6">
               <h3 className="text-xs uppercase tracking-[0.3em] font-black text-brand-blue-main">The Holy Bible</h3>
               <button onClick={() => setShowBookSelector(false)} className="text-gray-400 hover:text-brand-blue-main font-bold text-xs uppercase tracking-widest">Close</button>
            </div>

            <div className="flex-1 overflow-hidden flex gap-6">
              <div className="flex-1 flex flex-col gap-4 overflow-hidden">
                <h3 className="text-[10px] uppercase tracking-widest font-bold text-gray-400">Books (Gen - Rev)</h3>
                <div className="flex-1 overflow-y-auto space-y-1 custom-scrollbar pr-2">
                  {BIBLE_BOOKS.map(book => (
                    <button
                      key={book.id}
                      onClick={() => {
                        setSelectedBook(book);
                        setSelectedChapter(1);
                      }}
                      className={`w-full text-left px-4 py-3 rounded-xl text-sm font-bold transition-all ${selectedBook.id === book.id ? 'bg-brand-blue-main text-white shadow-lg' : 'text-gray-500 hover:bg-brand-blue-main/5 hover:text-brand-blue-main'}`}
                    >
                      {book.name}
                    </button>
                  ))}
                </div>
              </div>
              <div className="w-1/3 flex flex-col gap-4 overflow-hidden">
                <h3 className="text-[10px] uppercase tracking-widest font-bold text-gray-400">Chapter</h3>
                <div className="flex-1 overflow-y-auto grid grid-cols-1 gap-2 custom-scrollbar pr-2">
                  {Array.from({ length: selectedBook.chapters }, (_, i) => i + 1).map(chap => (
                    <button
                      key={chap}
                      onClick={() => {
                        setSelectedChapter(chap);
                        setShowBookSelector(false);
                      }}
                      className={`h-12 w-full flex items-center justify-center rounded-xl text-sm font-black transition-all ${selectedChapter === chap ? 'bg-brand-blue-main text-white shadow-md' : 'bg-gray-50 border border-gray-100 text-gray-400 hover:border-brand-blue-main/50'}`}
                    >
                      {chap}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Scripture Content */}
      <main className="flex-1 p-8 pb-32 max-w-2xl mx-auto w-full">
        {loading ? (
          <div className="flex flex-col justify-center items-center h-full pt-20 space-y-4">
             <div className="w-8 h-8 border-2 border-brand-blue-main border-t-transparent rounded-full animate-spin" />
             <div className="text-brand-blue-main/60 font-serif italic text-sm">Opening the scrolls...</div>
          </div>
        ) : (
          <div className="space-y-10">
            {verses.map((v, index) => {
              const isPlaying = playingVerseId === v.id;
              return (
                <motion.div
                  key={v.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ 
                    opacity: 1, 
                    y: 0,
                    backgroundColor: isPlaying ? 'rgba(3, 105, 161, 0.05)' : 'rgba(255, 255, 255, 0)',
                    scale: isPlaying ? 1.02 : 1
                  }}
                  transition={{ 
                    delay: index * 0.03,
                    duration: 0.3
                  }}
                  className={`group relative p-4 -mx-4 rounded-3xl border-l-4 transition-all duration-500 ${isPlaying ? 'border-brand-gold shadow-sm' : 'border-transparent'}`}
                >
                  <div className="flex gap-6">
                    <span className={`text-[10px] font-black mt-2 min-w-[24px] uppercase transition-colors ${isPlaying ? 'text-brand-blue-main' : 'text-brand-blue-main/30'}`}>
                      {v.verse}
                    </span>
                    <div className="space-y-4 flex-1">
                      <p 
                        onClick={() => handlePlayVerse(v)}
                        className={`text-xl leading-relaxed font-serif cursor-pointer selection:bg-brand-blue-main/20 transition-colors ${isPlaying ? 'text-brand-blue-main font-medium italic' : 'text-brand-ink hover:text-brand-blue-main/70'}`}
                      >
                        {v.text}
                      </p>
                      <div className={`flex gap-4 text-gray-300 transition-all ${isPlaying ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}>
                         <button onClick={() => handlePlayVerse(v)} className="hover:text-brand-blue-main transition-colors">
                            {playingVerseId === v.id ? <Pause size={16} /> : <Play size={16} />}
                         </button>
                         <button onClick={() => handleShare(v)} className="hover:text-brand-blue-main transition-colors">
                            <Share2 size={16} />
                         </button>
                         <button className="hover:text-brand-blue-main transition-colors">
                            <Bookmark size={16} />
                         </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
            
            {/* Navigation Footer */}
            <div className="pt-10 flex justify-between items-center bg-white p-6 rounded-[32px] border border-brand-blue-main/5 mt-10 shadow-sm">
               <button 
                  disabled={selectedChapter === 1 && BIBLE_BOOKS.findIndex(b => b.id === selectedBook.id) === 0}
                  onClick={() => {
                    if (selectedChapter > 1) {
                        setSelectedChapter(selectedChapter - 1);
                    } else {
                        const idx = BIBLE_BOOKS.findIndex(b => b.id === selectedBook.id);
                        if (idx > 0) {
                            setSelectedBook(BIBLE_BOOKS[idx - 1]);
                            setSelectedChapter(BIBLE_BOOKS[idx - 1].chapters);
                        }
                    }
                  }}
                  className="text-xs font-black uppercase tracking-widest text-brand-blue-main hover:text-brand-blue-light disabled:opacity-20"
                >
                  Previous
               </button>
               <div className="h-1 w-8 bg-brand-blue-main/10 rounded-full" />
               <button 
                  disabled={selectedChapter === selectedBook.chapters && BIBLE_BOOKS.findIndex(b => b.id === selectedBook.id) === BIBLE_BOOKS.length - 1}
                  onClick={() => {
                    if (selectedChapter < selectedBook.chapters) {
                        setSelectedChapter(selectedChapter + 1);
                    } else {
                        const idx = BIBLE_BOOKS.findIndex(b => b.id === selectedBook.id);
                        if (idx < BIBLE_BOOKS.length - 1) {
                            setSelectedBook(BIBLE_BOOKS[idx + 1]);
                            setSelectedChapter(1);
                        }
                    }
                  }}
                  className="text-xs font-black uppercase tracking-widest text-brand-blue-main hover:text-brand-blue-light disabled:opacity-20"
                >
                  Next
               </button>
            </div>
          </div>
        )}
      </main>

      {/* Audio Player Container (Invisible if not playing) */}
      {audioUrl && (playingVerseId || isPlayingChapter) && (
        <audio 
          ref={audioRef}
          src={audioUrl} 
          autoPlay 
          onEnded={() => {
            setPlayingVerseId(null);
            setIsPlayingChapter(false);
            setAudioUrl(null);
          }}
          className="hidden"
        />
      )}
    </div>
  );
}
