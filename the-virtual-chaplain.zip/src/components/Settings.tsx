
import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bell, Type, Languages, Cloud, Shield, LogOut, ChevronRight, User, Clock, Check, Camera, Book, Edit3 } from 'lucide-react';

import { useLanguage } from '../context/LanguageContext';

export default function Settings() {
  const { language, setLanguage, t } = useLanguage();
  const [displayName, setDisplayName] = useState('Jonah Ssemps');
  const [translation, setTranslation] = useState('GNT');
  const [profilePic, setProfilePic] = useState('https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200&h=200&fit=crop');
  const [fontSize, setFontSize] = useState('md');
  const [remindersEnabled, setRemindersEnabled] = useState(true);
  const [reminderTime, setReminderTime] = useState('08:00');
  const [isEditingProfile, setIsEditingProfile] = useState(false);

  const translationsVersions = ['GNT', 'KJV', 'NIV', 'ESV'];
  const avatarPresets = [
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1599566150163-29194dcaad36?q=80&w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?q=80&w=200&h=200&fit=crop',
  ];

  const sections = [
    {
      title: 'Appearance',
      items: [
        { id: 'font', label: t('fontSize'), icon: Type, value: fontSize.toUpperCase(), action: () => setFontSize(fontSize === 'lg' ? 'sm' : fontSize === 'sm' ? 'md' : 'lg') },
        { id: 'translation', label: t('bibleVersion'), icon: Book, value: translation, action: () => setTranslation(translationsVersions[(translationsVersions.indexOf(translation) + 1) % translationsVersions.length]) },
      ]
    },
    {
      title: t('remindersSync'),
      items: [
        { 
          id: 'notifications', 
          label: t('dailyReminders'), 
          icon: Bell, 
          value: remindersEnabled ? t('active') : t('disabled'), 
          action: () => setRemindersEnabled(!remindersEnabled),
          customOverlay: true
        },
        { id: 'cloud', label: t('cloudBackup'), icon: Cloud, value: 'Last synced 2h ago' },
        { id: 'lang', label: t('language'), icon: Languages, value: language, action: () => setLanguage(language === 'English' ? 'French' : 'English') },
      ]
    }
  ];

  return (
    <div className="p-6 space-y-8 pb-32">
      <header className="space-y-4 pt-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
             <div className="relative group">
               <div className="w-16 h-16 rounded-3xl overflow-hidden shadow-xl border-2 border-brand-blue-main/10">
                  <img 
                    src={profilePic} 
                    alt="Profile" 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
               </div>
               <button 
                 onClick={() => setIsEditingProfile(true)}
                 className="absolute -bottom-1 -right-1 w-6 h-6 bg-brand-blue-main text-white rounded-lg flex items-center justify-center shadow-lg hover:scale-110 transition-transform"
               >
                 <Camera size={12} />
               </button>
             </div>
             <div>
                <h1 className="text-xl font-serif font-bold text-brand-ink">{displayName}</h1>
                <p className="text-[10px] text-brand-blue-main font-bold uppercase tracking-widest">{t('devoutSoul')}</p>
             </div>
          </div>
          <button 
            onClick={() => setIsEditingProfile(true)}
            className="p-2 text-brand-blue-main/40 hover:text-brand-blue-main transition-colors"
          >
            <Edit3 size={20} />
          </button>
        </div>
      </header>

      <AnimatePresence>
        {isEditingProfile && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-6"
            onClick={() => setIsEditingProfile(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-[40px] p-8 max-w-md w-full shadow-2xl space-y-6"
              onClick={e => e.stopPropagation()}
            >
              <h2 className="text-xl font-serif font-bold text-brand-ink">{t('editProfile')}</h2>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest font-black text-brand-blue-main/40 ml-1">{t('displayName')}</label>
                  <input 
                    type="text"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    className="w-full bg-brand-blue-main/5 border-none rounded-2xl px-5 py-4 text-sm font-bold text-gray-700 focus:ring-2 focus:ring-brand-blue-main/20 outline-none"
                    placeholder="Enter your name"
                  />
                </div>

                <div className="space-y-3">
                  <label className="text-[10px] uppercase tracking-widest font-black text-brand-blue-main/40 ml-1">{t('chooseAvatar')}</label>
                  <div className="flex justify-between gap-2">
                    {avatarPresets.map((url, i) => (
                      <button 
                        key={i}
                        onClick={() => setProfilePic(url)}
                        className={`w-14 h-14 rounded-2xl overflow-hidden border-2 transition-all ${profilePic === url ? 'border-brand-blue-main scale-110 shadow-lg' : 'border-transparent opacity-60 hover:opacity-100'}`}
                      >
                        <img src={url} alt="preset" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <button 
                onClick={() => setIsEditingProfile(false)}
                className="w-full bg-brand-blue-main text-white py-4 rounded-2xl font-black uppercase tracking-widest text-xs shadow-lg hover:bg-brand-blue-main/90 transition-all"
              >
                {t('saveChanges')}
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="space-y-8">
        {/* Special Daily Reminders Control */}
        <section className="space-y-3">
          <h2 className="text-[10px] uppercase tracking-[0.2em] font-black text-brand-blue-main/30 px-3">{t('spiritualDiscipline')}</h2>
          <div className="bg-white rounded-[32px] border border-brand-blue-main/5 overflow-hidden shadow-sm p-6 space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-2xl bg-brand-blue-main/10 flex items-center justify-center text-brand-blue-main">
                  <Bell size={20} />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-gray-700">{t('dailyPrayerReminder')}</h3>
                  <p className="text-[10px] text-gray-400 font-medium">{t('receiveVerse')}</p>
                </div>
              </div>
              <button 
                onClick={() => setRemindersEnabled(!remindersEnabled)}
                className={`w-12 h-6 rounded-full transition-all duration-300 relative ${remindersEnabled ? 'bg-brand-blue-main' : 'bg-gray-200'}`}
              >
                <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all duration-300 ${remindersEnabled ? 'left-7' : 'left-1'}`} />
              </button>
            </div>

            {remindersEnabled && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="pt-4 border-t border-gray-50 flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                   <Clock size={16} className="text-brand-blue-main" />
                   <span className="text-xs font-bold text-gray-500 uppercase tracking-widest">{t('setTime')}</span>
                </div>
                <input 
                  type="time" 
                  value={reminderTime}
                  onChange={(e) => setReminderTime(e.target.value)}
                  className="bg-brand-blue-main/5 border-none rounded-xl px-4 py-2 text-sm font-black text-brand-blue-main focus:ring-2 focus:ring-brand-blue-main/20 outline-none"
                />
              </motion.div>
            )}
          </div>
        </section>

        {sections.map((section, idx) => (
          <section key={idx} className="space-y-3">
             <h2 className="text-[10px] uppercase tracking-[0.2em] font-black text-brand-blue-main/30 px-3">{section.title}</h2>
             <div className="bg-white rounded-[32px] border border-brand-blue-main/5 overflow-hidden shadow-sm">
                {section.items.map((item, i) => (
                  <button
                    key={item.id}
                    onClick={item.action}
                    className={`w-full flex items-center justify-between p-5 hover:bg-brand-blue-main/5 transition-colors ${i < section.items.length - 1 ? 'border-b border-brand-blue-main/5' : ''}`}
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-2xl bg-brand-blue-main/10 flex items-center justify-center text-brand-blue-main">
                        <item.icon size={20} />
                      </div>
                      <span className="text-sm font-bold text-gray-700">{item.label}</span>
                    </div>
                    <div className="flex items-center gap-2">
                       <span className="text-xs font-bold text-brand-blue-main">{item.value}</span>
                       <ChevronRight size={14} className="text-gray-300" />
                    </div>
                  </button>
                ))}
             </div>
          </section>
        ))}
      </div>

      <button className="w-full p-5 flex items-center justify-center gap-3 text-white font-black text-xs uppercase tracking-widest bg-brand-blue-main rounded-[24px] border border-brand-blue-main/10 mt-6 active:scale-95 transition-transform shadow-lg">
        <LogOut size={18} /> {t('signOut')}
      </button>

      <footer className="text-center space-y-2 pt-8">
         <p className="text-[10px] text-brand-blue-main/20 font-bold uppercase tracking-[0.3em]">THE VIRTUAL CHAPLAIN • v1.3</p>
         <p className="text-[10px] text-brand-blue-main/10 uppercase font-bold tracking-widest">Eternal Connection</p>
      </footer>
    </div>
  );
}
