
import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, User, Bot, Sparkles, RefreshCcw, Church, Share2 } from 'lucide-react';
import { getChaplainResponse } from '../services/geminiService';

interface Message {
  role: 'user' | 'model';
  text: string;
}

export default function Chaplain() {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: 'Peace be with you. I am The Virtual Chaplain. How can I guide you today? Whether you seek understanding of a verse or a moment of prayer, I am here.' }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;

    const userMessage: Message = { role: 'user', text: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    try {
      const history = messages.map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));
      
      const response = await getChaplainResponse(history, input);
      setMessages(prev => [...prev, { role: 'model', text: response || 'I am reflecting on your words...' }]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'model', text: 'Peace be with you. I am having trouble connecting, but I will be here when you return.' }]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleShare = () => {
    const conversation = messages
      .map(m => `${m.role === 'user' ? 'Me' : 'Chaplain'}: ${m.text}`)
      .join('\n\n');
    
    if (navigator.share) {
      navigator.share({
        title: 'Spiritual Guidance - Virtual Chaplain',
        text: conversation
      });
    } else {
      navigator.clipboard.writeText(conversation);
      alert('Conversation copied to clipboard!');
    }
  };

  return (
    <div className="h-screen flex flex-col bg-brand-blue-bg overflow-hidden">
      <header className="p-4 border-b border-brand-blue-main/5 bg-white/50 backdrop-blur-md flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-brand-blue-main flex items-center justify-center text-white shadow-lg">
            <Church size={24} />
          </div>
          <div>
            <h2 className="font-serif font-bold text-brand-ink">The Virtual Chaplain</h2>
            <span className="text-[10px] text-brand-blue-main uppercase tracking-[0.2em] font-black">Digital Ministry</span>
          </div>
        </div>
        <button 
          onClick={() => setMessages([{ role: 'model', text: 'May we start our spiritual journey anew. How can I assist you?' }])}
          className="p-2 text-gray-400 hover:text-brand-blue-main transition-colors"
        >
          <RefreshCcw size={18} />
        </button>
      </header>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-6">
        {messages.map((msg, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div className={`max-w-[85%] flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
              <div className={`w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center ${msg.role === 'user' ? 'bg-brand-blue-main text-white' : 'bg-brand-blue-main/10 text-brand-blue-main'}`}>
                {msg.role === 'user' ? <User size={16} /> : <Church size={14} />}
              </div>
              <div className={`p-4 rounded-[24px] ${msg.role === 'user' ? 'bg-brand-blue-main text-white rounded-tr-none shadow-md' : 'bg-white text-gray-700 shadow-sm border border-brand-blue-main/5 rounded-tl-none'}`}>
                <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.text}</p>
              </div>
            </div>
          </motion.div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-white/50 p-4 rounded-2xl rounded-tl-none border border-brand-blue-main/5 animate-pulse">
               <span className="text-[10px] text-brand-blue-main font-serif italic uppercase tracking-widest">Chaplain is reflecting...</span>
            </div>
          </div>
        )}
      </div>

      <div className="p-4 bg-white border-t border-brand-blue-main/5 pb-32">
        <div className="max-w-2xl mx-auto flex gap-2">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Seek guidance or verses..."
            className="flex-1 bg-brand-blue-bg border border-brand-blue-main/10 rounded-full px-6 py-4 text-sm text-brand-ink placeholder:text-brand-blue-main/30 focus:ring-2 focus:ring-brand-blue-main/20 outline-none transition-all"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || isTyping}
            className="w-14 h-14 rounded-full bg-brand-blue-main text-white flex items-center justify-center hover:bg-brand-blue-main/90 transition-all active:scale-90 disabled:opacity-50 shadow-lg"
          >
            <Send size={24} />
          </button>
          <button
            onClick={handleShare}
            className="w-14 h-14 rounded-full bg-white border border-brand-blue-main/10 text-brand-blue-main flex items-center justify-center hover:bg-brand-blue-main hover:text-white transition-all active:scale-90 shadow-sm"
          >
            <Share2 size={24} />
          </button>
        </div>
      </div>
    </div>
  );
}
